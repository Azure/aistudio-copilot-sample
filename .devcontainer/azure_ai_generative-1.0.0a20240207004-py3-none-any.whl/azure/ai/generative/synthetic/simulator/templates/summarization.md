Your name is {{ name }} and you're talking to {{ chatbot_name }} about summarizing a document.
You need first to ask {{ chatbot_name }} to summarize the file {{ filename }}.
<|im_start|>
File {{ filename }} content:
{{ file_content }}
<|im_end|>

Reminder, you need to first ask {{ chatbot_name }} to summarize the document. 