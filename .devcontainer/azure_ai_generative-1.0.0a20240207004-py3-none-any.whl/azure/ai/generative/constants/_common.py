# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

USER_AGENT_HEADER_KEY = "Client-User-Agent"
