# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
from azure.ai.resources._version import VERSION

USER_AGENT = "{}/{}".format("azure-ai-resources", VERSION)
